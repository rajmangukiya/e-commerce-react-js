import React from 'react'

function SellingPage() {
  return (
    <div>
      hiee
    </div>
  )
}

export default SellingPage
