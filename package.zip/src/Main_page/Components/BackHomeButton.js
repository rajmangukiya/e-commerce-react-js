import React from 'react'
import { Link } from 'react-router-dom'

function BackHomeButton() {
  return (
    <Link to="/" className="BackHomeButton">
        
    </Link>
  )
}

export default BackHomeButton
